
# Receta Python 7-3: Agregar campos privados.


class ClaseDemo:
    __atributo_privado__ = 'valor'

