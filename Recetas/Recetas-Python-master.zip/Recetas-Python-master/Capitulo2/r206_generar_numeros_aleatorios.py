
# Receta 2-6:Generar números aleatorios

import random

print(random.random())

print(random.randint(0, 10))

primos = [2, 3, 5, 7]

print(random.choice(primos))
