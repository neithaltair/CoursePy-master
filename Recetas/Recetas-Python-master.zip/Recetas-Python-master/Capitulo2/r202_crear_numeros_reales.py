
# Receta 2-2: Crear números reales

# 1. A través de literales
# 2. Es por medio de la función float()

decimal1 = 3.1415

decimal2 = float('3.1415')

decimal3 = float(input('Escriba un número real: '))

decimal4 = 1e3 # 1000

print(decimal1)
print(decimal2)
print(decimal3)
print(decimal4)
