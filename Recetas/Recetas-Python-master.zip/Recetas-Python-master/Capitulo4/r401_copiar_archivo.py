
# Receta 4-1: Copiar un archivo

# copy()

import shutil

ruta_nuevo_archivo = shutil.copy('paises.csv', 'paises2.csv')

print(ruta_nuevo_archivo)

# copy2()
