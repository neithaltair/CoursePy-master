
# Receta 4-2: Mover un archivo

import shutil

shutil.move('paises2.csv', 'sub_directorio', copy_function=shutil.copy)
