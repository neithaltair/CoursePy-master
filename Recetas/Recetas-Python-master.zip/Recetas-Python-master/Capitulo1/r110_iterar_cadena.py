
# Iterar una cadena de caracteres:

# 1. Utilizar los índices a través de un ciclo for
# 2. Utilizar un iterador

frase = 'Python 3.7'

for i in range(len(frase)):
    print(frase[i])


for caracter in frase:
    print(caracter)
