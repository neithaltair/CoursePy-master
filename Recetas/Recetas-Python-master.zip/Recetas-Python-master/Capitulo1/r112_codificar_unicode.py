
# Receta 1-12: Codificar una cadena de caracteres en Unicode:

# unicode('Python')

lenguaje1 = 'Python'
lenguaje2 = u'Python'

print(lenguaje1 == lenguaje2)
