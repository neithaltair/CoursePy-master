
# Receta 2-1: Crear números enteros

# 1. literales
# 2. entrada del usuario

entero = 29

numero = int(input('Escriba un número: '))

print(entero, numero)

print(numero.bit_length())

binario = '111'

representacion_entera = int(binario, 2)

print(representacion_entera)

