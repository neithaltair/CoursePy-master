# ==: a nivel de contenido
# is: a nivel de referencia

lenguaje = 'Python'

if lenguaje == 'python':
    print('Las cadenas de caracteres son iguales')
else:
    print('Las cadenas de caracteres NO son iguales')


lenguaje_python = lenguaje

if lenguaje_python is lenguaje:
    print('Las referencias son iguales')
else:
    print('Las referencias no son iguales.')

