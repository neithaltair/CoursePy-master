# 1. A través del operador polimórfico in
# 2. A través del método find (string)

lenguaje = 'Python es un lenguaje de programación'

print('python' in lenguaje)

print(lenguaje.find('programación'))
