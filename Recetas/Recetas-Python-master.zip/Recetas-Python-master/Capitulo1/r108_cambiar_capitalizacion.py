
# Cambiar entre mayúsculas y minúsculas

# upper, lower, capitalize

frase = 'python es un tremendo!'

print(frase.upper())
print(frase.lower())
print(frase.capitalize())


