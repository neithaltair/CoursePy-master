
# Calcular estadísticas básicas sobre una cadena de caracteres:


# longitud, el carácter máximo y mínimo, y el número de ocurrencias de un carácter:

frase = 'Python es un lenguaje de programación'

print(len(frase))

print(min(frase))

print(max(frase))

print(frase.count('o'))
