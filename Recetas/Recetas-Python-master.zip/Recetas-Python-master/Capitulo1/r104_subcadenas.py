lenguaje = 'Python es genial'

# variable[x:y]

# print(len(lenguaje))

# print(lenguaje[-5])

print(lenguaje[0:6])

print(lenguaje[0:lenguaje.find('n') + 1])