lenguaje = 'Python'
version = 3

print(type(lenguaje))
print(type(version))

lenguaje_version = lenguaje + ' ' + str(version)

print(lenguaje_version)
