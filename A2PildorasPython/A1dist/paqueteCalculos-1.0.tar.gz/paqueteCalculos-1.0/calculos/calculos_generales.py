def sumar(op1,op2):
    print("Suma es = ",op1+op2)

def multiplicar(op1,op2):
    print("Multi es = ",op1*op2)


def restar(op1,op2):
    print("resta es = ",op1-op2)


def dividir(op1,op2):
    print("dividir es = ",op1/op2)


def potencia(op1,op2):
    print("potencia es = ",op1**op2)


def redondear(numero):
    print("redondear es = ",round(numero))


    