
def potencia(op1,op2):
    print("potencia es = ",op1**op2)


def redondear(numero):
    print("redondear es = ",round(numero))

