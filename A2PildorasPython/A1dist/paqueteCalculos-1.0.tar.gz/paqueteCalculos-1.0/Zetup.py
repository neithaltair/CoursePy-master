from setuptools import setup 

setup(

    name="paqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="NeithAltair",
    author_email="neith.altair.na@gmail.com",
    packages=["calculos","calculos.redondeo_potencia"]




)